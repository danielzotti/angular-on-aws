# AngularOnAws

## Prerequisites
- AWS cli
    - See [AWS documentation](https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html)
- Angular cli
    - `npm install -g @angular/cli`
- Serverless framework
    - `npm install serverless`
- Create user credentials on AWS 
    - See [AWS documentation](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_users_create.html)

## What I've done
- Configure serverless credentials (with custom profile)
    - `serverless config credentials --provider aws --key {KEY} --secret {SECRET} --profile aws-on-aws`
- Create Angular project from cli 
    - `ng new angular-on-aws` (`npm install` run automatically after project creation)
    - `cd angular-on-aws`
- Add serverless plugin
    - `ng add @ng-toolkit/serverless`
- Fix missing `serverless-api-compression` package in @ng-toolkit/serverless
    - `npm install serverless-api-compression`
- Customize configuration `serverless.yml` (`region` and `profile`)
```yaml
provider:
  region: eu-west-3
  profile: angular-on-aws

```
- Deploy the project to AWS)
    - `npm run build:serverless:deploy`